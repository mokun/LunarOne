/**
 * Filename:    LunarOneCityGame.java 
 * Author:      Manny Kung
 * Date:   		31 Oct 2011
 * Revision:	0
 * Subject:     LunarOneCity--my first java-based game
 * Input:      
 * Output:      
 * */
//import javax.swing.*;
//import java.awt.event.*;

public class LunarOneCityGame {

	public static void main(String[] args) {
						
		LunarOneCity lc = new LunarOneCity();
	}
}
